import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.security import create_access_token

client = TestClient(app)

@pytest.mark.api
def test_health_endpoint():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"

@pytest.mark.api
def test_register_endpoint():
    response = client.post(
        "/api/v1/auth/register",
        json={
            "email": "api_test@example.com",
            "password": "TestPassword123!",
            "full_name": "API Test",
            "organization_name": "API Test Org"
        }
    )
    assert response.status_code == 200
    data = response.json()
    assert "user_id" in data
    assert "message" in data

@pytest.mark.api
def test_register_duplicate_email():
    client.post(
        "/api/v1/auth/register",
        json={
            "email": "duplicate@example.com",
            "password": "TestPassword123!",
            "full_name": "First User",
            "organization_name": "First Org"
        }
    )
    response = client.post(
        "/api/v1/auth/register",
        json={
            "email": "duplicate@example.com",
            "password": "TestPassword123!",
            "full_name": "Second User",
            "organization_name": "Second Org"
        }
    )
    assert response.status_code == 400

@pytest.mark.api
def test_login_endpoint():
    client.post(
        "/api/v1/auth/register",
        json={
            "email": "login_test@example.com",
            "password": "TestPassword123!",
            "full_name": "Login Test",
            "organization_name": "Login Test Org"
        }
    )
    response = client.post(
        "/api/v1/auth/login",
        json={
            "email": "login_test@example.com",
            "password": "TestPassword123!"
        }
    )
    assert response.status_code == 200
    data = response.json()
    assert "access_token" in data
    assert data["token_type"] == "bearer"

@pytest.mark.api
def test_login_wrong_password():
    client.post(
        "/api/v1/auth/register",
        json={
            "email": "wrong_pw@example.com",
            "password": "CorrectPassword123!",
            "full_name": "Test",
            "organization_name": "Test"
        }
    )
    response = client.post(
        "/api/v1/auth/login",
        json={
            "email": "wrong_pw@example.com",
            "password": "WrongPassword123!"
        }
    )
    assert response.status_code == 401

@pytest.mark.api
def test_get_current_user_without_auth():
    response = client.get("/api/v1/auth/me")
    assert response.status_code in [401, 403]

@pytest.mark.api
def test_get_current_user_with_auth():
    token = create_access_token({"sub": "test_user_id"})
    response = client.get(
        "/api/v1/auth/me",
        headers={"Authorization": f"Bearer {token}"}
    )
    assert response.status_code in [200, 404, 401]

@pytest.mark.api
def test_barcode_endpoint_requires_auth():
    response = client.get("/api/v1/labels/test-barcode/qr/TEST123")
    assert response.status_code in [401, 403]

@pytest.mark.api
def test_barcode_endpoint_with_auth():
    token = create_access_token({"sub": "test_user_id"})
    response = client.get(
        "/api/v1/labels/test-barcode/qr/TEST123",
        headers={"Authorization": f"Bearer {token}"}
    )
    assert response.status_code in [200, 404, 401]

@pytest.mark.api
def test_labels_list_requires_auth():
    response = client.get("/api/v1/labels/")
    assert response.status_code in [401, 403]

@pytest.mark.api
def test_generate_simple_requires_auth():
    response = client.post(
        "/api/v1/labels/generate-simple?text=Test&code=123&barcode_type=qr"
    )
    assert response.status_code in [401, 403]
